<template>
  <CampRegister></CampRegister>
</template>

<script setup>
  import CampRegister from '../components/Camping/CampRegister.vue';
</script>
