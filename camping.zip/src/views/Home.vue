<template>
  <!-- <MainSwiper></MainSwiper> -->
  <!-- <UserManage></UserManage> -->
  <CampDetail></CampDetail>
  <!-- <CampRegister></CampRegister> -->
</template>

<script setup>
  import MainSwiper from '@/components/MainSwiper.vue';
  import CampRegister from '@/components/Camping/CampRegister.vue';
  import CampDetail from '../components/Camping/CampDetail.vue';
  import UserManage from '@/components/Admin/UserManage.vue';
  // import LoginSignup from '@/components/LoginSignup.vue';
</script>
